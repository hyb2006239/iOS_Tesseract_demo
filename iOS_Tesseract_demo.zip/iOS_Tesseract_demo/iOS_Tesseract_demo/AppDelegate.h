//
//  AppDelegate.h
//  iOS_Tesseract_demo
//
//  Created by 黄云碧 on 2018/12/18.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

